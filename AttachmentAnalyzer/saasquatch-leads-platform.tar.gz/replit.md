# Lead Generation and Email Outreach Platform

## Overview

This is a full-stack lead generation and email outreach platform built with React, Express, and PostgreSQL. The application allows users to scrape leads from various sources, enrich them with additional data, and generate personalized email campaigns using AI. It features a modern dashboard with analytics, filtering capabilities, and comprehensive lead management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and building
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom design system and dark mode support
- **State Management**: React Query (TanStack Query) for server state management
- **Routing**: Wouter for client-side routing
- **Charts**: Chart.js for analytics visualization

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Design**: RESTful API with structured error handling
- **Development**: Hot reload with Vite integration

### Database Schema
The application uses a relational database structure with the following main entities:
- **Companies**: Business information, industry, size, revenue, location
- **Contacts**: Individual contact details linked to companies
- **Leads**: Lead scoring, status tracking, and source attribution
- **Enrichment Data**: Additional data from various sources stored as JSON
- **Email Campaigns**: Campaign tracking and performance metrics

## Key Components

### Lead Management System
- **Lead Scraping**: Mock integration with Apollo.io, LinkedIn, and Crunchbase
- **Lead Enrichment**: AI-powered data enhancement service
- **Lead Scoring**: Automated scoring system (0-100 scale)
- **Status Tracking**: Pipeline management (pending, enriched, contacted, converted)

### Email Generation Service
- **AI-Powered**: OpenAI GPT-4o integration for personalized email generation
- **Template System**: Pre-built templates for different industries and use cases
- **Campaign Management**: Email campaign tracking and analytics
- **Personalization**: Dynamic content based on lead and company data

### Dashboard and Analytics
- **Real-time Statistics**: Lead counts, enrichment rates, conversion metrics
- **Interactive Charts**: Time-series analytics with Chart.js
- **Advanced Filtering**: Multi-criteria search and filtering system
- **Export Capabilities**: CSV export functionality for lead data

### UI/UX Components
- **Design System**: Consistent component library with shadcn/ui
- **Responsive Design**: Mobile-first approach with Tailwind CSS
- **Dark Mode**: Theme switching capability
- **Accessibility**: ARIA-compliant components from Radix UI

## Data Flow

1. **Lead Acquisition**: Users can scrape leads from external sources or manually add them
2. **Data Enrichment**: Leads are automatically enriched with additional company and contact information
3. **Lead Scoring**: AI-powered scoring system evaluates lead quality
4. **Campaign Creation**: Users generate personalized emails using AI templates
5. **Analytics Tracking**: System tracks engagement and conversion metrics

## External Dependencies

### Core Dependencies
- **Database**: Neon Database (serverless PostgreSQL)
- **ORM**: Drizzle ORM for type-safe database operations
- **AI Service**: OpenAI API for email generation
- **UI Components**: Radix UI primitives with shadcn/ui styling

### Data Sources (Mock Integrations)
- **Apollo.io**: Lead scraping and enrichment
- **LinkedIn Sales Navigator**: Professional networking data
- **Crunchbase**: Company funding and business intelligence
- **ZoomInfo**: Contact and company information

### Development Tools
- **Replit Integration**: Development environment optimization
- **TypeScript**: Type safety across the entire stack
- **ESLint/Prettier**: Code quality and formatting
- **Hot Reload**: Development experience optimization

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: esbuild compiles TypeScript server to `dist/index.js`
- **Database**: Drizzle Kit handles schema migrations

### Environment Configuration
- **Development**: Local development with Vite dev server
- **Production**: Express serves static files and API endpoints
- **Database**: PostgreSQL connection via DATABASE_URL environment variable

### Scripts
- `npm run dev`: Development server with hot reload
- `npm run build`: Production build for both frontend and backend
- `npm run start`: Production server
- `npm run db:push`: Database schema synchronization

The application follows a monorepo structure with shared TypeScript types and schemas, enabling type safety across the entire stack while maintaining clear separation between frontend, backend, and shared code.